﻿
### Answer Key

1. B
2. B
3. D
4. B
5. D
6. B
7. B
8. A
9. B
10. A
11. A
12. D
13. B
14. B
15. C
16. A

Feel free to use this quiz as a comprehensive assessment for Week 6.

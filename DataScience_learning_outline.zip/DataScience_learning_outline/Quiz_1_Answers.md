﻿---  <details> <summary>Answers</summary>  

1.  A) 15
2.  A list is mutable and allows duplicate elements, whereas a tuple is immutable and allows duplicate elements.
3.  A) `def`
4.  `if x > 0:
        print("Positive")`
    
5.  A) 0 1 2
6.  Dictionary
7.  B) `import math`
8.  A) `git init`
9.  The `git clone` command is used to clone (or copy) a repository from an existing URL.
10.  B) `git add`
11.  False
12.  The primary role of a `README.md` file is to provide documentation for the project.
13.  B) `git log`
14.  C) Tracking changes in code
15.  pull
    

</details>

﻿    ---  <details> <summary>Answers</summary>  
    
    1.  A) `open("file.txt", "r")`
    2.  `try` is used to wrap the code that may throw an exception. `except` is used to catch and handle the exception. `finally` is used to execute code that must run regardless of whether an exception occurred or not.
    3.  D) `z`
    4.  `class Calculator:
            def add(self, a, b):
                return a + b
            def subtract(self, a, b):
                return a - b`
        
    5.  B) File not found.
    6.  Objects
    7.  The primary advantage of OOP is that it allows for code reusability and can make the code more organized and manageable.
    8.  A) `SELECT * FROM Students`
    9.  The `WHERE` clause is used to filter records based on specific conditions.
    10.  A) `INSERT INTO`
    11.  False
    12.  The `UPDATE` statement is used to modify existing records in a table.
    13.  B) `DROP TABLE`
    14.  A) `ALTER TABLE`
    15.  `ORDER BY`
    16.  `SELECT * FROM Students WHERE Score > 90`
    17.  You can use the `sqlite3` library in Python to connect to an SQLite database using `sqlite3.connect("database_name.db")`.
        
    
    </details>
